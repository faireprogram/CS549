package edu.stevens.cs549.ftpclient;

public interface Itest {

	public void sayHello();
}
